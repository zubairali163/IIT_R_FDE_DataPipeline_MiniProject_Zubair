# Lead Intelligence System

Reads a CSV of leads, scores each 1-10, decides **qualified / review / rejected**, ranks them, and writes 3 short first-message variants for every qualified lead. Output: `output_report.json`.

## How to run
Needs Python 3.9+.
```powershell
pip install groq pyyaml
$env:GROQ_API_KEY = "your-key"       # terminal only; never stored in any file
python main.py                        # leads.csv -> output_report.json (100 leads, scored as of 2024-01-21)
python main.py --mock                 # offline: no key, no API calls
python main.py --input leads_edge_cases.csv --output edge.json --as-of 2024-01-21
python main.py --input leads_robustness.csv --output robust.json --as-of 2026-10-27
python test_rules.py ; python test_llm.py    # offline tests
```
Settings (model, batch sizes, rubric, thresholds, message offer) are in `config.yaml`; `--no-cache` ignores saved LLM results.

## Rubric (10 points)
Company size 0-3 (100-1,000 employees highest), industry fit 0-2 (LLM), lead source 0-2 (referral, demo request, sales call = 2; webinar, content download = 1; outbound or unknown = 0), recency 0-2 (within 30 days = 2, within 90 = 1), completeness 0-1. **8+ qualified, 4 or less rejected, 5-7 review** (too close to call). Missing size, industry or date always goes to review; last contact over 365 days ago, or a size scoring 0, can never qualify (capped to review).

## Design choices and why
- **Code scores the facts, the LLM judges only industry fit and writes messages.** The same lead gets the same points every run, and calls stay small.
- **Knockout caps.** Testing showed a lead last contacted in 2022 and a 50,000-employee company qualifying at exactly 7, so they now go to a human.
- **Qualify line is 8, not 7.** At 7, 81 of 100 leads qualified, too many to be a useful filter.
- **Missing data goes to review, never a guess.**
- **Messages are short and use only facts we hold** (name, company, source). Earlier drafts invented claims about companies, so each message is checked in code: at most 45 words, ends with a one-word choice, no invented claims, variants open differently.
- **Failure handling.** Leads go in batches (10 scoring, 5 messages). Rate limits and errors are retried with backoff; invalid replies are retried for only the failed leads; a batch that keeps failing is split; a lead still without valid messages gets a template marked `template_fallback`. Groq throttled us with waits of about 13 minutes, so waits over 15 minutes are not obeyed (the batch is flagged) and results are cached in `.llm_cache.json` so a run can resume.

## Assumptions
We sell business software to mid-market companies. Size ranges use their midpoint; ambiguous dates like `05/10/2026` go to review. Messages offer a "20-minute walkthrough" (set in `config.yaml`).

## Known limitations
- No ground truth, so weights and thresholds are judgement, not validated on real conversions.
- LLM industry scores are slightly generous and can differ between runs by a few leads.
- The sample data is clean and recent, so more leads qualify than a real list would give.
- Messages are plain by design, not tailored to a lead's real needs.
- The free Groq tier throttles heavy use, so big runs can be slow.
- The shipped report used `openai/gpt-oss-20b`; `openai/gpt-oss-120b` may score more reliably.
