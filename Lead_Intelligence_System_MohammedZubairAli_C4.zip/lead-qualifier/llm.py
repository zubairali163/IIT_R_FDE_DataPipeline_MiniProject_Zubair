"""Everything that talks to Groq: industry-fit scoring in batches, with retries and a mock mode.
The API key is read from the GROQ_API_KEY environment variable only."""
import hashlib
import json
import os
import re
import time
from collections import Counter

SYSTEM_PROMPT = (
    "You are a B2B sales analyst. Our product is business software for mid-market companies "
    "(operations, customer data, workflow automation). For each lead, judge how likely their "
    "INDUSTRY is to buy this kind of software.\n"
    "Score industry_fit as an integer: 2 = strong fit (data-heavy, operations-heavy, regulated or "
    "fast-growing industries), 1 = possible fit, 0 = unlikely to buy (very local, tiny-ticket, "
    "or non-commercial sectors).\n"
    'Reply with JSON only, exactly: {"results": [{"id": <int>, "industry_fit": <0|1|2>, '
    '"reason": "<max 15 words>"}]}. Include every id you were given.'
)

# Used by --mock so the whole pipeline can run offline, without a key.
MOCK_FIT = {
    "fintech": 2, "healthcare": 2, "logistics": 2, "e-commerce": 2, "saas": 2, "insurance": 2,
    "telecom": 2, "manufacturing": 1, "retail": 1, "education": 1, "media": 1, "real estate": 1,
    "energy": 1, "construction": 1, "staffing": 1,
    "finance": 2, "edtech": 2, "software": 2, "enterprise software": 2, "technology": 2,
    "cybersecurity": 2, "analytics": 2, "supply chain": 2, "pharmaceuticals": 2,
    "consulting": 1, "marketing": 1, "legal": 1, "travel": 1, "events": 1,
}


def get_client():
    key = os.environ.get("GROQ_API_KEY")
    if not key:
        raise SystemExit("GROQ_API_KEY is not set in this terminal. Set it, or run with --mock.")
    from groq import Groq
    return Groq(api_key=key)


def mock_industry_fit(batch):
    return {
        lead["id"]: {"industry_fit": MOCK_FIT.get(lead["industry"].lower(), 0),
                     "reason": "mock mode: fixed industry table"}
        for lead in batch
    }


def _extract_json(text):
    """Parse the model reply; tolerate stray text around the JSON object."""
    try:
        return json.loads(text)
    except (json.JSONDecodeError, TypeError):
        m = re.search(r"\{.*\}", text or "", re.DOTALL)
        if not m:
            raise ValueError("no JSON object in reply")
        return json.loads(m.group(0))


def _validate(data, batch):
    """Keep only well-formed results for ids we actually sent."""
    wanted = {lead["id"] for lead in batch}
    good = {}
    for r in data.get("results", []):
        try:
            lead_id, fit = int(r["id"]), int(r["industry_fit"])
        except (KeyError, TypeError, ValueError):
            continue
        if lead_id in wanted and fit in (0, 1, 2):
            good[lead_id] = {"industry_fit": fit, "reason": str(r.get("reason", ""))[:200]}
    return good


def _call_once(client, batch, cfg):
    payload = [{"id": l["id"], "company": l["company"], "industry": l["industry"]} for l in batch]
    r = client.chat.completions.create(
        model=cfg["llm"]["model"],
        messages=[{"role": "system", "content": SYSTEM_PROMPT},
                  {"role": "user", "content": json.dumps(payload)}],
        temperature=cfg["llm"]["temperature"],
        reasoning_effort=cfg["llm"]["reasoning_effort"],
        max_completion_tokens=cfg["llm"]["max_completion_tokens"],
        response_format={"type": "json_object"},
    )
    return _validate(_extract_json(r.choices[0].message.content), batch)


def _is_fatal(err):
    """Auth / bad-request errors will never succeed on retry; rate limits and 5xx will."""
    return getattr(err, "status_code", None) in (400, 401, 403, 404)


def run_batch(client, batch, cfg, call, log=print):
    """Return {lead_id: result} for as many leads as possible.
    Each attempt only asks for leads that are still missing. Errors are retried with
    exponential backoff (honouring Retry-After). If nothing at all succeeds for a batch of
    several leads, it is split in half so one bad lead can't sink the others."""
    llm = cfg["llm"]
    result, wait, pending = {}, llm["backoff_seconds"], list(batch)
    for attempt in range(1, llm["max_retries"] + 1):
        try:
            result.update(call(client, pending, cfg))
        except Exception as err:  # noqa: BLE001 - classified below
            if _is_fatal(err):
                log(f"  fatal API error, not retrying: {type(err).__name__}: {err}")
                return result
            headers = getattr(getattr(err, "response", None), "headers", None) or {}
            wait = float(headers.get("retry-after", wait)) if hasattr(headers, "get") else wait
            if wait > llm.get("max_wait_seconds", 900):
                log(f"  server asks for {wait:.0f}s, longer than max_wait_seconds; giving up on this batch for now")
                return result
            log(f"  attempt {attempt}/{llm['max_retries']} failed ({type(err).__name__}); waiting {wait:.0f}s")
            time.sleep(wait)
            wait *= 2
            continue
        pending = [l for l in batch if l["id"] not in result]
        if not pending:
            return result
        log(f"  attempt {attempt}/{llm['max_retries']}: {len(pending)} lead(s) missing or invalid, retrying them")
    if len(pending) == len(batch) and len(batch) > 1:     # no progress at all: split and retry halves
        mid = len(batch) // 2
        log(f"  splitting batch of {len(batch)}")
        result.update(run_batch(client, batch[:mid], cfg, call, log))
        result.update(run_batch(client, batch[mid:], cfg, call, log))
    return result


# ---------------------------------------------------------------- result cache
# Validated LLM results are saved to disk (never the API key). A re-run, or a run resumed after
# Ctrl+C or a rate limit, only calls the API for leads it has not already finished.
_CACHE = {"path": None, "data": {}}


def cache_init(path):
    _CACHE["path"], _CACHE["data"] = path, {}
    if path and os.path.exists(path):
        try:
            with open(path, encoding="utf-8") as f:
                _CACHE["data"] = json.load(f)
        except (OSError, ValueError):
            _CACHE["data"] = {}          # unreadable cache: start fresh, never crash


def _cache_save():
    if _CACHE["path"]:
        tmp = _CACHE["path"] + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(_CACHE["data"], f)
        os.replace(tmp, _CACHE["path"])


def _ckey(*parts):
    return hashlib.sha1("|".join(map(str, parts)).encode("utf-8")).hexdigest()


def _cached_run(client, batch, cfg, call, key_fn, log):
    """Serve leads from the cache, call the API only for the rest, and cache what validated."""
    keys = {l["id"]: key_fn(l) for l in batch}
    result = {i: _CACHE["data"][k] for i, k in keys.items() if _CACHE["path"] and k in _CACHE["data"]}
    todo = [l for l in batch if l["id"] not in result]
    if len(todo) < len(batch):
        log(f"  {len(batch) - len(todo)} of {len(batch)} lead(s) served from cache")
    if todo:
        got = run_batch(client, todo, cfg, call, log)
        if _CACHE["path"]:
            for i, v in got.items():
                _CACHE["data"][keys[i]] = v
            _cache_save()
        result.update(got)
    return result


def judge_batch(client, batch, cfg, log=print):
    key = lambda l: _ckey("fit", cfg["llm"]["model"], SYSTEM_PROMPT, l["company"], l["industry"])
    return _cached_run(client, batch, cfg, _call_once, key, log)


# ---------------------------------------------------------------- outreach messages
MESSAGE_PROMPT = (
    "You write first-contact sales messages. For each lead write exactly 3 DIFFERENT short variants. "
    "The offer we are making is: {offer}.\n"
    "FACTS: you know only the person's name, company, industry, company size, lead source and last "
    "interaction date. Never state or guess anything else about their business, challenges or goals. "
    "No flattery, no claims about us, no numbers, no 'I noticed', no 'I saw'.\n"
    "LENGTH: each message is at most 40 words.\n"
    "ASK: every message must end with a choice of two that the reader can answer in ONE word, "
    "for example: Reply \"Thu\" or \"Fri\".\n"
    "VARIANTS differ in what they ask AND in how they open (after the 'Hi <first name>,' greeting):\n"
    "  Variant 1 (pick a day): opens by thanking them for how they reached us, then offers the {offer} "
    "and asks for a day, e.g. Thursday or Friday.\n"
    "  Variant 2 (pick a format): opens straight with a question: would a quick call or a short email suit "
    "them better.\n"
    "  Variant 3 (right person): opens with 'Quick check:' and asks whether they are the right person at "
    "the company or it should go to someone else ('me' or 'someone else').\n"
    "STYLE: sound like a person writing a quick note, not a form. Name their company in EVERY variant "
    "(for example 'at <company>'). Refer to how they reached us in plain words ('your demo request', "
    "'the webinar', 'your referral'), never the raw label. Phrase asks as polite questions, not commands. "
    "Do not mention dates. No emojis, no jargon such as 'synergies' or 'strategy'.\n"
    'Reply with JSON only, exactly: {{"results": [{{"id": <int>, "variants": [{{"angle": "<2-3 words>", '
    '"message": "<text>"}}, ...exactly 3 items]}}]}}. Include every id you were given.'
)

# Phrases that signal invented facts, promises or empty sales talk; such a message is rejected and retried.
BANNED = re.compile(
    r"i(?:'ve)? noticed|i saw|i see that|i suspect|i believe|\broi\b|guarantee|%|synerg|strateg|forefront|"
    r"cutting-edge|game-chang|best-in-class|leverag|revolution|industry-leading",
    re.IGNORECASE,
)
MAX_WORDS = 45          # prompt asks for 40; small tolerance


def _opening(text):
    """First 4 words after a 'Hi <name>,' greeting, used to catch variants that open alike."""
    body = re.sub(r"^\s*(?:hi|hello|hey)\s+[^,]{1,40},\s*", "", text, flags=re.IGNORECASE)
    return " ".join(body.lower().split()[:4])


REJECTS = Counter()   # why message variants were rejected; printed at the end of a run
_SUFFIXES = {"inc", "inc.", "corp", "corp.", "ltd", "ltd.", "llc", "co", "co."}


def _company_core(company):
    """'TechVentures Inc' -> 'techventures'; '&' and 'and' treated alike."""
    words = [w for w in company.lower().replace("&", "and").split() if w not in _SUFFIXES]
    return " ".join(words)


def _validate_messages(data, batch):
    """A lead's 3 variants are accepted when: there are 3 distinct messages of at most 45 words,
    none makes invented claims or uses empty sales talk, each ends with a choice-of-two ask, every message names the person or the company, and at
    least 2 of the 3 name the company."""
    by_id = {l["id"]: l for l in batch}
    good = {}
    for r in data.get("results", []):
        try:
            lead = by_id[int(r["id"])]
            variants = [{"angle": str(v.get("angle", ""))[:40], "message": str(v["message"]).strip()}
                        for v in r["variants"]]
        except (KeyError, TypeError, ValueError, AttributeError):
            REJECTS["malformed entry"] += 1
            continue
        n_returned = len(variants)
        if n_returned > 3:                       # extra variants are harmless: keep the first 3
            variants = variants[:3]
        texts = [v["message"] for v in variants]
        low = [t.lower().replace("&", "and") for t in texts]
        first = (lead["name"].split() or [""])[0].lower()
        core = _company_core(lead["company"])
        if len(variants) != 3:
            reason = f"fewer than 3 variants (got {n_returned})"
        elif len(set(texts)) != 3:
            reason = "duplicate variants"
        elif any(len(t) < 40 for t in texts):
            reason = "message too short"
        elif len({_opening(t) for t in texts}) < 3:
            reason = "variants open the same way"
        elif any(len(t.split()) > MAX_WORDS for t in texts):
            reason = "message too long"
        elif any(BANNED.search(t) for t in texts):
            reason = "invented claim or promise"
        elif any(not re.search(r"\bor\b", t[-110:], re.IGNORECASE) for t in texts):
            reason = "no one-word choice ask"
        elif any(not ((first and first in t) or (core and core in t)) for t in low):
            reason = "message names neither person nor company"
        elif core and sum(core in t for t in low) < 2:
            reason = "company named in fewer than 2 variants"
        else:
            good[lead["id"]] = variants
            continue
        REJECTS[reason] += 1
    return good


def _call_messages(client, batch, cfg):
    payload = [{"id": l["id"], "name": l["name"], "company": l["company"], "industry": l["industry"],
                "company_size": l["company_size"], "lead_source": l["source"],
                "last_interaction_date": l["last_interaction_date"]} for l in batch]
    r = client.chat.completions.create(
        model=cfg["llm"]["model"],
        messages=[{"role": "system", "content": MESSAGE_PROMPT.format(offer=cfg["messages"]["offer"])},
                  {"role": "user", "content": json.dumps(payload)}],
        temperature=0.7,                       # a little variety is wanted for writing
        reasoning_effort=cfg["llm"]["reasoning_effort"],
        max_completion_tokens=cfg["llm"]["max_completion_tokens"],
        response_format={"type": "json_object"},
    )
    return _validate_messages(_extract_json(r.choices[0].message.content), batch)


def message_batch(client, batch, cfg, log=print):
    prompt = MESSAGE_PROMPT.format(offer=cfg["messages"]["offer"])
    key = lambda l: _ckey("msg", cfg["llm"]["model"], prompt,
                          *(l.get(k, "") for k in ("name", "company", "industry", "company_size", "source")))
    return _cached_run(client, batch, cfg, _call_messages, key, log)


def template_messages(batch, offer="20-minute walkthrough"):
    """Plain, fact-safe messages in the same easy-reply style. Used by --mock and as the fallback
    when the LLM cannot produce valid messages for a lead. They pass the same validator."""
    out = {}
    for l in batch:
        first = (l["name"].split() or ["there"])[0]
        src = l["source"].lower() if l["source"] else ""
        opener = f"following up with {l['company']} ({src})" if src else f"reaching out to {l['company']}"
        out[l["id"]] = [
            {"angle": "pick a day", "message": f"Hi {first}, {opener}. Would Thursday or Friday suit you for a {offer}? Reply \"Thu\" or \"Fri\"."},
            {"angle": "pick a format", "message": f"Hi {first}, would a quick call or a short email be easier for {l['company']}? Reply \"call\" or \"email\"."},
            {"angle": "right person", "message": f"Hi {first}, am I reaching the right person at {l['company']} about this, or someone else? Reply \"me\" or send a name."},
        ]
    return out


mock_messages = template_messages
