"""Lead Intelligence System: score, decide, rank and report on a CSV of leads.
Usage:  python main.py            (real Groq calls; needs GROQ_API_KEY in the terminal)
        python main.py --mock     (offline, no key needed)"""
import argparse
import json
from collections import Counter
from datetime import date

import llm
from scoring import code_score, load_config, load_leads

TIER = {"qualified": 0, "review": 1, "rejected": 2}


def decide(total, flags, cfg, c, today):
    """Return (decision, why). Missing critical data always wins over the score;
    knockout caps stop a high score from hiding a deal-breaker."""
    if flags:
        return "review", "needs a human: " + "; ".join(flags)
    t = cfg["thresholds"]
    if total >= t["qualified_min"]:
        caps, rules = [], cfg["caps"]
        if c["parsed_date"] and (today - date.fromisoformat(c["parsed_date"])).days > rules["max_days_since_contact"]:
            caps.append(f"last contact over {rules['max_days_since_contact']} days ago")
        if rules["size_points_zero_blocks"] and c["size_points"] == 0:
            caps.append("company size outside target range")
        if caps:
            return "review", f"score {total} would qualify but is capped to review: " + "; ".join(caps)
        return "qualified", f"score {total} meets the qualified threshold ({t['qualified_min']}+)"
    if total <= t["rejected_max"]:
        return "rejected", f"score {total} is at or below the reject threshold ({t['rejected_max']})"
    return "review", f"score {total} is too close to call ({t['rejected_max'] + 1}-{t['qualified_min'] - 1})"


def rejection_reasons(c, fit):
    """Name the factors that scored zero; used for the 'common rejection reasons' stat."""
    reasons = []
    if c["size_points"] == 0: reasons.append("company size outside target range")
    if fit == 0: reasons.append("industry unlikely to buy")
    if c["source_points"] == 0: reasons.append("weak or unknown lead source")
    if c["recency_points"] == 0: reasons.append("no recent engagement")
    return reasons


def score_all(leads, cfg, today, mock, log=print):
    # 1. rule-based scores for every lead
    coded = {l["id"]: code_score(l, cfg, today) for l in leads}
    # 2. LLM industry fit, in batches, only for leads that have an industry
    askable = [l for l in leads if l["industry"]]
    size = cfg["llm"]["batch_size"]
    client = None if mock else llm.get_client()
    fits = {}
    for i in range(0, len(askable), size):
        batch = askable[i:i + size]
        log(f"industry-fit batch {i // size + 1}/{-(-len(askable) // size)} ({len(batch)} leads)")
        fits.update(llm.mock_industry_fit(batch) if mock else llm.judge_batch(client, batch, cfg, log))
    return coded, fits


def build_rows(leads, coded, fits, cfg, today):
    rows = []
    for l in leads:
        c, f = coded[l["id"]], fits.get(l["id"])
        flags = list(c["flags"])
        if l["industry"] and f is None:
            flags.append("LLM could not score industry fit")
        fit = f["industry_fit"] if f else 0
        total = c["size_points"] + c["source_points"] + c["recency_points"] + c["completeness_points"] + fit
        decision, why = decide(total, flags, cfg, c, today)
        rows.append({
            "id": l["id"], "name": l["name"], "company": l["company"],
            "company_size": l["company_size"], "industry": l["industry"],
            "source": l["source"], "last_interaction_date": l["last_interaction_date"],
            "score": max(1, min(10, total)),
            "provisional_score": bool(flags),
            "breakdown": {"company_size": c["size_points"], "industry_fit": fit,
                          "source_quality": c["source_points"], "recency": c["recency_points"],
                          "completeness": c["completeness_points"]},
            "decision": decision,
            "reasoning": why + (f". Industry: {f['reason']}" if f else ""),
            "rejection_factors": rejection_reasons(c, fit) if decision == "rejected" else [],
            "_recency_key": c["parsed_date"] or "0000-00-00",
        })
    # priority: qualified first, then review, then rejected; within a tier higher score first,
    # then the most recently active lead
    rows.sort(key=lambda r: (TIER[r["decision"]], -r["score"], -int(r["_recency_key"].replace("-", ""))))
    for rank, r in enumerate(rows, start=1):
        r["priority_rank"] = rank
        del r["_recency_key"]
    return rows


def summarize(rows):
    n = len(rows)
    counts = Counter(r["decision"] for r in rows)
    why = Counter(f for r in rows for f in r["rejection_factors"])
    return {
        "total_processed": n,
        "qualified": counts["qualified"], "review": counts["review"], "rejected": counts["rejected"],
        "qualified_pct": round(100 * counts["qualified"] / n, 1) if n else 0,
        "common_rejection_reasons": [{"reason": k, "count": v} for k, v in why.most_common(5)],
    }


def add_messages(rows, leads, cfg, mock, log=print):
    """Write 3 outreach variants for every qualified lead, in batches."""
    by_id = {l["id"]: l for l in leads}
    todo = [by_id[r["id"]] for r in rows if r["decision"] == "qualified"]
    size = cfg["messages"]["batch_size"]
    client = None if mock else llm.get_client()
    got = {}
    for i in range(0, len(todo), size):
        batch = todo[i:i + size]
        log(f"message batch {i // size + 1}/{-(-len(todo) // size)} ({len(batch)} leads)")
        got.update(llm.template_messages(batch, cfg["messages"]["offer"]) if mock else llm.message_batch(client, batch, cfg, log))
    missing = [by_id[r["id"]] for r in rows if r["decision"] == "qualified" and r["id"] not in got]
    fallback = llm.template_messages(missing, cfg["messages"]["offer"])
    for r in rows:
        if r["decision"] == "qualified":
            r["message_source"] = "llm" if r["id"] in got and not mock else ("template" if mock else "template_fallback")
            r["messages"] = got.get(r["id"]) or fallback[r["id"]]
    if missing and not mock:
        log(f"WARNING: {len(missing)} lead(s) used template_fallback messages (LLM output failed validation)")
    if llm.REJECTS:
        log("message variants rejected, by reason: " + ", ".join(f"{k}={v}" for k, v in llm.REJECTS.most_common()))
    return got


def sample_messages(rows, n):
    """Pick n qualified leads with messages, spread across the ranking (not just the top n)."""
    ok = [r for r in rows if r.get("messages")]
    if len(ok) <= n:
        picks = ok
    else:
        picks = [ok[round(i * (len(ok) - 1) / (n - 1))] for i in range(n)]
    return [{"name": r["name"], "company": r["company"], "score": r["score"], "variants": r["messages"]}
            for r in picks]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.yaml")
    ap.add_argument("--input", help="leads CSV (default: from config)")
    ap.add_argument("--output", help="report path (default: from config)")
    ap.add_argument("--as-of", help="scoring date YYYY-MM-DD (default: today, or config as_of_date)")
    ap.add_argument("--no-cache", action="store_true", help="ignore and do not write the LLM result cache")
    ap.add_argument("--mock", action="store_true", help="offline run without calling Groq")
    ap.add_argument("--limit", type=int, help="only process the first N leads (for quick tests)")
    args = ap.parse_args()

    cfg = load_config(args.config)
    if args.input: cfg["run"]["input_csv"] = args.input
    if args.output: cfg["run"]["output_report"] = args.output
    if args.as_of: cfg["run"]["as_of_date"] = args.as_of
    today = date.fromisoformat(cfg["run"]["as_of_date"]) if cfg["run"]["as_of_date"] else date.today()
    leads = load_leads(cfg["run"]["input_csv"])[: args.limit]
    llm.cache_init(None if (args.no_cache or args.mock) else cfg["run"].get("cache_file", ".llm_cache.json"))
    print(f"loaded {len(leads)} leads, scoring as of {today}{' (MOCK mode)' if args.mock else ''}")

    coded, fits = score_all(leads, cfg, today, args.mock)
    rows = build_rows(leads, coded, fits, cfg, today)
    add_messages(rows, leads, cfg, args.mock)
    qualified = [r for r in rows if r["decision"] == "qualified"]
    report = {"as_of_date": today.isoformat(), "model": "mock" if args.mock else cfg["llm"]["model"],
              "summary": summarize(rows) | {
                  "messages_written_by_llm": sum(r["message_source"] == "llm" for r in qualified),
                  "messages_from_template_fallback": sum(r["message_source"] == "template_fallback" for r in qualified),
                  "message_variants_rejected_by_reason": dict(llm.REJECTS)}, "leads": rows, "sample_messages": sample_messages(rows, cfg["messages"]["sample_count_in_report"])}
    with open(cfg["run"]["output_report"], "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)   # ASCII-escaped: readable on any platform
    s = report["summary"]
    print(f"done: {s['qualified']} qualified, {s['review']} review, {s['rejected']} rejected "
          f"({s['qualified_pct']}% qualified) -> {cfg['run']['output_report']}")


if __name__ == "__main__":
    main()
