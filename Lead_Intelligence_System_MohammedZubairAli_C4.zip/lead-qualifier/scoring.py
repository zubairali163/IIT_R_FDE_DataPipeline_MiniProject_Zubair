"""Rule-based part of the lead score: cleaning messy values and scoring the facts.
The LLM only judges industry fit (see main.py). Everything here is deterministic."""
import re
import csv
from datetime import date, datetime

import yaml

# Text that stands in for "no data"; treated exactly like a blank cell.
PLACEHOLDERS = {"na", "n/a", "none", "null", "nan", "-", "unknown", "unknown sector", "unknown source"}
FIELDS = ["name", "company", "company_size", "industry", "source", "last_interaction_date"]


def load_config(path="config.yaml"):
    with open(path, encoding="utf-8") as f:
        return yaml.safe_load(f)


def load_leads(path):
    """Read the CSV. Every lead gets an id and all six fields (missing -> empty string)."""
    leads = []
    with open(path, newline="", encoding="utf-8") as f:
        for i, row in enumerate(csv.DictReader(f), start=1):
            lead = {k: (row.get(k) or "").strip() for k in FIELDS}
            for k in FIELDS:
                if lead[k].lower() in PLACEHOLDERS:
                    lead[k] = ""
            lead["id"] = i
            leads.append(lead)
    return leads


def parse_size(raw):
    """'1,200' -> 1200, '~250' -> 250, '50-100' -> 75 (midpoint). 'Enterprise' or blank -> None."""
    if not raw:
        return None
    s = raw.replace(",", "").replace("~", "").strip()
    m = re.fullmatch(r"(\d+)\s*[-–to]+\s*(\d+)", s)
    if m:
        return (int(m.group(1)) + int(m.group(2))) // 2
    return int(s) if s.isdigit() else None


def parse_date(raw, today):
    """Accepts 2026-10-05 and 'Oct 3, 2026'. Slash dates like 05/10/2026 are ambiguous
    (day/month vs month/day), so they return None and the lead goes to review.
    Dates in the future are also invalid -> None."""
    if not raw:
        return None
    for fmt in ("%Y-%m-%d", "%b %d, %Y", "%d %b %Y"):
        try:
            d = datetime.strptime(raw, fmt).date()
            return d if d <= today else None
        except ValueError:
            pass
    return None


def score_size(size, cfg):
    if size is None:
        return 0
    for band in cfg["rubric"]["company_size"]:
        if band["min"] <= size <= band["max"]:
            return band["points"]
    return 0


def score_source(source, cfg):
    return cfg["rubric"]["source_quality"].get(source.lower().strip(), 0)


def score_recency(d, today, cfg):
    if d is None:
        return 0
    days = (today - d).days
    for band in cfg["rubric"]["recency"]:
        if days <= band["within_days"]:
            return band["points"]
    return 0


def code_score(lead, cfg, today):
    """Score the four rule-based factors and flag problems that force human review."""
    size = parse_size(lead["company_size"])
    d = parse_date(lead["last_interaction_date"], today)
    flags = []
    if size is None:
        flags.append("company size missing or unreadable")
    if not lead["industry"]:
        flags.append("industry missing")
    if d is None:
        flags.append("last interaction date missing or unreadable")
    complete = all(lead[k] for k in FIELDS)
    return {
        "size_points": score_size(size, cfg),
        "source_points": score_source(lead["source"], cfg),
        "recency_points": score_recency(d, today, cfg),
        "completeness_points": cfg["rubric"]["completeness"]["all_fields_points"] if complete else 0,
        "parsed_size": size,
        "parsed_date": d.isoformat() if d else None,
        "flags": flags,
    }


if __name__ == "__main__":
    cfg = load_config()
    today = date.fromisoformat(cfg["run"]["as_of_date"]) if cfg["run"]["as_of_date"] else date.today()
    leads = load_leads(cfg["run"]["input_csv"])
    flagged = 0
    for lead in leads[:8]:
        print(lead["name"] or "(no name)", "|", code_score(lead, cfg, today))
    flagged = sum(1 for l in leads if code_score(l, cfg, today)["flags"])
    print(f"\n{len(leads)} leads loaded, {flagged} have problems that force review")
