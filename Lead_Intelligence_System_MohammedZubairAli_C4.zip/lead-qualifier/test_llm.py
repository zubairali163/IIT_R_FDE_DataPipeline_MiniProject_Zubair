"""Offline tests for llm.py using a fake client that fails the ways Groq can fail."""
import json
import llm
from scoring import load_config

llm.time.sleep = lambda s: None          # don't really wait during tests
cfg = load_config()
quiet = lambda *a, **k: None
batch = [{"id": i, "company": f"Co{i}", "industry": "Fintech"} for i in range(1, 5)]


class ApiError(Exception):
    def __init__(self, status): super().__init__(f"HTTP {status}"); self.status_code = status


class Fake:
    """Each item in `script` is a reply string, or an Exception to raise."""
    def __init__(self, script): self.script, self.calls = list(script), 0
        # expose client.chat.completions.create like the real SDK
    @property
    def chat(self): return self
    @property
    def completions(self): return self
    def create(self, **kw):
        self.calls += 1
        step = self.script.pop(0)
        if isinstance(step, Exception): raise step
        msg = type("M", (), {"content": step})()
        return type("R", (), {"choices": [type("C", (), {"message": msg})()]})()


def reply(ids, fit=2):
    return json.dumps({"results": [{"id": i, "industry_fit": fit, "reason": "ok"} for i in ids]})


def check(name, cond):
    print(("PASS" if cond else "FAIL"), name)
    assert cond


# 1. happy path
c = Fake([reply([1, 2, 3, 4])])
check("happy path returns 4 results in 1 call", len(llm.judge_batch(c, batch, cfg, quiet)) == 4 and c.calls == 1)

# 2. rate limit (429) then success
c = Fake([ApiError(429), reply([1, 2, 3, 4])])
check("retries after rate limit", len(llm.judge_batch(c, batch, cfg, quiet)) == 4 and c.calls == 2)

# 3. malformed JSON then success
c = Fake(["sorry, here you go: not json", reply([1, 2, 3, 4])])
check("retries after malformed JSON", len(llm.judge_batch(c, batch, cfg, quiet)) == 4 and c.calls == 2)

# 4. JSON wrapped in extra text is still parsed
c = Fake(["Here:\n" + reply([1, 2, 3, 4]) + "\nDone."])
check("extracts JSON from surrounding text", len(llm.judge_batch(c, batch, cfg, quiet)) == 4)

# 5. model drops a lead -> only that lead is retried
c = Fake([reply([1, 2, 3]), reply([4])])
check("retries only the dropped lead", len(llm.judge_batch(c, batch, cfg, quiet)) == 4 and c.calls == 2)

# 6. invalid score (7) is rejected
c = Fake([reply([1, 2, 3, 4], fit=7)] * 40)
check("out-of-range scores are never accepted", llm.judge_batch(c, batch, cfg, quiet) == {})

# 7. auth error is fatal: no retries
c = Fake([ApiError(401)])
check("401 stops immediately", llm.judge_batch(c, batch, cfg, quiet) == {} and c.calls == 1)

# 8. mock mode needs no key
check("mock mode works offline", len(llm.mock_industry_fit(batch)) == 4)
# ---- message tests (easy-reply style) ----
lead = {"id": 1, "name": "Priya Nair", "company": "FinEdge Pay", "industry": "Fintech", "source": "Referral", "company_size": "320", "last_interaction_date": "2026-10-05"}
def msgs(texts): return json.dumps({"results": [{"id": 1, "variants": [{"angle": "a", "message": t} for t in texts]}]})
good = ['Hi Priya, thanks to your referral I would love to show FinEdge Pay a 20-minute walkthrough. Thursday or Friday? Reply "Thu" or "Fri".',
        'Priya, would a quick call or a short email be easier for FinEdge Pay? Reply "call" or "email".',
        'Hi Priya, am I reaching the right person at FinEdge Pay about this, or someone else? Reply "me" or send a name.']

c = Fake([msgs(good)])
check("valid messages accepted", len(llm.message_batch(c, [lead], cfg, quiet).get(1, [])) == 3)

c = Fake([msgs([good[0], good[0], good[2]]), msgs(good)])
check("duplicate variants rejected then retried", len(llm.message_batch(c, [lead], cfg, quiet).get(1, [])) == 3 and c.calls == 2)

generic = ["Hi Priya, great to meet you, want a quick call about our software today?",
           "Hi Priya, we would love to tell you more about what we do. Any interest?",
           "Hello Priya, are you free sometime soon to chat about your needs?"]
c = Fake([msgs(generic)] * 40)
check("generic messages without company or choice ask are rejected", llm.message_batch(c, [lead], cfg, quiet) == {})

claims = ['Hi Priya, we guarantee ROI for FinEdge Pay. Thursday or Friday?',
          'Priya, FinEdge Pay could see 30% savings. Call or email?',
          'Hi Priya, I noticed FinEdge Pay is growing. Me or someone else?']
c = Fake([msgs(claims)] * 40)
check("invented facts, numbers and promises are rejected", llm.message_batch(c, [lead], cfg, quiet) == {})

buzz = ['Hi Priya, FinEdge Pay is at the forefront of Fintech. Thursday or Friday?',
        'Priya, lets discuss synergies for FinEdge Pay. Call or email?',
        'Hi Priya, lets align on strategy for FinEdge Pay. Me or someone else?']
c = Fake([msgs(buzz)] * 40)
check("flattery and buzzwords are rejected", llm.message_batch(c, [lead], cfg, quiet) == {})

long_ = [good[0] + " " + "word " * 40, good[1], good[2]]
c = Fake([msgs(long_)] * 40)
check("messages over 45 words are rejected", llm.message_batch(c, [lead], cfg, quiet) == {})

nochoice = ["Hi Priya, would FinEdge Pay like to hear more sometime soon?",
            "Priya, FinEdge Pay may find a short chat useful. Interested?",
            "Hi Priya, shall I send FinEdge Pay an overview?"]
c = Fake([msgs(nochoice)] * 40)
check("messages with no choice-of-two ask are rejected", llm.message_batch(c, [lead], cfg, quiet) == {})

same_open = ['Hi Jack, thanks for your demo request at Acme Co. Thursday or Friday? Reply "Thu" or "Fri".',
             'Hi Jack, thanks for your demo request at Acme Co. Call or email? Reply "call" or "email".',
             'Hi Jack, thanks for your demo request at Acme Co. Me or someone else? Reply "me" or send a name.']
leadj = {"id": 1, "name": "Jack White", "company": "Acme Co", "industry": "Marketing", "source": "Inbound demo request"}
c = Fake([msgs(same_open)] * 40)
check("variants that open the same way are rejected", llm.message_batch(c, [leadj], cfg, quiet) == {})

lead2 = {"id": 1, "name": "Bob Rodriguez", "company": "TechVentures Inc", "industry": "SaaS", "source": "LinkedIn outreach", "company_size": "8", "last_interaction_date": "2024-01-20"}
ok2 = ['Hi Bob, would TechVentures prefer a call or an email? Reply "call" or "email".',
       'TechVentures and a 20-minute walkthrough: Thursday or Friday, Bob?',
       'Hi Bob, am I reaching the right person, or someone else? Reply "me" or send a name.']
c = Fake([msgs(ok2)])
check("company without Inc suffix is accepted", len(llm.message_batch(c, [lead2], cfg, quiet).get(1, [])) == 3)
check("rejection reasons are recorded", sum(llm.REJECTS.values()) > 0)

four = ok2 + ['Bob, TechVentures: Thursday or Friday for a walkthrough?']
c = Fake([msgs(four)])
check("extra 4th variant is trimmed to 3", len(llm.message_batch(c, [lead2], cfg, quiet).get(1, [])) == 3)
c = Fake([msgs(ok2[:2])] * 40)
check("only 2 variants is rejected", llm.message_batch(c, [lead2], cfg, quiet) == {})

# the template fallback must pass the very same validator, even with a blank name or source
for name, src in [("Bob Rodriguez", "LinkedIn outreach"), ("", ""), ("Priya Nair", "Referral")]:
    L = {"id": 1, "name": name, "company": "TechVentures Inc", "industry": "SaaS", "source": src}
    tm = llm.template_messages([L])[1]
    accepted = llm._validate_messages({"results": [{"id": 1, "variants": tm}]}, [L])
    check(f"template fallback passes the validator (name={name!r}, source={src!r})", 1 in accepted)
# ---- cache and max-wait tests ----
import os, tempfile
tmp = os.path.join(tempfile.mkdtemp(), "cache.json")
llm.cache_init(tmp)
c1 = Fake([reply([1, 2, 3, 4])])
check("first run calls the API", len(llm.judge_batch(c1, batch, cfg, quiet)) == 4 and c1.calls == 1)
c2 = Fake([])                                    # would raise if called
check("second run is served entirely from the cache", len(llm.judge_batch(c2, batch, cfg, quiet)) == 4 and c2.calls == 0)
llm.cache_init(tmp)                              # simulate a new process reading the saved file
check("cache survives a restart", len(llm.judge_batch(Fake([]), batch, cfg, quiet)) == 4)
more = batch + [{"id": 5, "company": "Co5", "industry": "Fintech"}]
c3 = Fake([reply([5])])
check("only the new lead is sent to the API", len(llm.judge_batch(c3, more, cfg, quiet)) == 5 and c3.calls == 1)
open(tmp, "w").write("{not json")
llm.cache_init(tmp)
check("a corrupt cache file is ignored, not fatal", llm._CACHE["data"] == {})
llm.cache_init(None)                             # caching off again for the remaining tests

class Slow(Exception):
    status_code = 429
    response = type("R", (), {"headers": {"retry-after": "5000"}})()
c = Fake([Slow(), reply([1, 2, 3, 4])])
check("a very long server wait is not obeyed (gives up on the batch)", llm.judge_batch(c, batch, cfg, quiet) == {} and c.calls == 1)
print("\nall tests passed")
