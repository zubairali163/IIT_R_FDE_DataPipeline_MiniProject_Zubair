"""Offline tests for the decision rules (no API needed)."""
from datetime import date
from main import decide
from scoring import load_config

cfg = load_config()
today = date(2024, 1, 21)
ok = {"parsed_date": "2024-01-20", "size_points": 3}

def check(name, cond):
    print("PASS" if cond else "FAIL", name)
    assert cond

check("high score + healthy lead -> qualified", decide(9, [], cfg, ok, today)[0] == "qualified")
check("score 8 is the qualified line", decide(8, [], cfg, ok, today)[0] == "qualified")
check("score 7 is now too close to call", decide(7, [], cfg, ok, today)[0] == "review")
check("score 6 -> review", decide(6, [], cfg, ok, today)[0] == "review")
check("score 4 -> rejected", decide(4, [], cfg, ok, today)[0] == "rejected")
check("missing data -> review even at score 10", decide(10, ["industry missing"], cfg, ok, today)[0] == "review")
stale = {"parsed_date": "2022-06-15", "size_points": 3}
d, why = decide(8, [], cfg, stale, today)
check("stale contact caps a qualifying score to review", d == "review" and "capped" in why)
tiny = {"parsed_date": "2024-01-20", "size_points": 0}
check("size outside range caps to review", decide(9, [], cfg, tiny, today)[0] == "review")
check("caps never upgrade a rejected lead", decide(3, [], cfg, stale, today)[0] == "rejected")
exactly = {"parsed_date": "2023-01-21", "size_points": 3}   # exactly 365 days: allowed
check("exactly 365 days is not stale", decide(8, [], cfg, exactly, today)[0] == "qualified")
print("\nall tests passed")
